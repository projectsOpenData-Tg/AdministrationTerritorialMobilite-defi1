"""Thème du tableau de bord : polices, couleurs et styles des composants partagés.

Palette reprise strictement du plan du tableau de bord (11 §4.1), elle-même validée pour les daltonismes : rampe bleue
pour les classes, couleurs de priorité, couleurs de thème des objectifs, couleurs d'état du réseau, couleur par zone.
Les couleurs de base (fond, cartes, barre latérale) sont dans .streamlit/config.toml. Structure et CSS repris du
tableau de bord du défi « Économie numérique » (EconomyNumeric-Challenge2/dashboard/theme.py), adaptés à notre palette
et au français seul.
"""
import streamlit as st

# --- Neutres et structure (maquette §2.2) -----------------------------------------------------------------
ENCRE, ENCRE2, DISCRET, FILET, FOND, CARTE = "#172b3a", "#334155", "#64748b", "#e2e8f0", "#f4f2ec", "#ffffff"   # fond café conservé
BLEU_FONCE = "#0b263d"                     # bleu nuit : barre latérale, titres, chiffres clés
BLEU_ACTIF = "#1769aa"                     # navigation active, sélection des filtres
# Accents nationaux (drapeau) : vert = favorable, jaune = mise en évidence ou avertissement, rouge = risque élevé
VERT_DRAPEAU, JAUNE_DRAPEAU, ROUGE_DRAPEAU = "#006b3f", "#fcd116", "#ce1126"
# Une couleur fixe par donnée, identique sur toutes les pages
SERIE = {"Moto": "#16834a", "Voiture": "#2474c6", "Poids lourd": "#e6b422", "Bus et car": "#8293a7", "Autres": "#b6c0cc",
         "Accidents": "#ce1126", "Blessés": "#e87518", "Décès": "#8e1b2b", "Auto-écoles": "#2474c6"}

# --- Palettes de données (11 §4.1 ; ne pas changer) -------------------------------------------------------
BLEUS = ["#cde2fb", "#86b6ef", "#3987e5", "#1c5cab", "#0d366b"]            # rampe séquentielle, 5 classes
PRIORITE = {"Haute": "#0d366b", "Moyenne": "#3987e5", "Faible": "#cde2fb", "Non classée": "#b9b6ad"}
HORS_SELECTION = "#ebe8e0"
# Couleurs de thème des 4 objectifs (palette CATEGORIELLE de la maquette)
THEME = {"Mobilité": "#2474c6", "Sécurité routière": "#e87518", "Réseau": "#e6b422", "Couverture": "#16834a"}
CATEGORIELLE = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#008300"]  # séries d'un graphique
# États du réseau (11 §4.1 ; vérifiés pour les daltonismes)
ETAT = {"Bon": "#16834a", "Moyen": "#e6b422", "Mauvais": "#ce1126", "Travaux": "#8293a7", "Non évalué": "#b9b6ad"}
# Une couleur par zone, pour écrire son nom (la couleur suit la zone, jamais son rang)
COULEUR_ZONE = {"Grand Lomé": "#256abf", "Maritime hors Grand Lomé": "#008300", "Plateaux": "#ab6300",
                "Centrale": "#4a3aa7", "Kara": "#cb4b0c", "Savanes": "#bb537d"}

# Les 5 régions, dans la même palette validée (11 §4.1) : la Maritime englobe le Grand Lomé et reprend sa couleur.
COULEUR_REGION = {"Maritime": "#256abf", "Plateaux": "#ab6300", "Centrale": "#4a3aa7",
                  "Kara": "#cb4b0c", "Savanes": "#bb537d"}

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Fraunces:opsz,wght@9..144,500;9..144,600&family=IBM+Plex+Sans:wght@400;500;600&display=swap');
html, body, [class*="css"], .stMarkdown, .stText, button, input, label { font-family: 'IBM Plex Sans', system-ui, sans-serif; }
h1, h2, h3 { font-family: 'Fraunces', Georgia, serif !important; font-weight: 600 !important; letter-spacing: 0 !important; }

/* Contenu : largeur fluide, espacement latéral fixe (maquette §2.4) */
[data-testid="stMainBlockContainer"] { padding-top: 0.6rem; padding-bottom: 2rem; padding-left: 1.5rem !important;
  padding-right: 1.5rem !important; max-width: 100% !important; }
/* Streamlit place un en-tête opaque dès qu'il affiche un bouton (Fork/GitHub sur Streamlit Cloud, réouverture de la
   barre latérale) : on ne réserve sa hauteur que dans ce cas (maquette §4, règle à appliquer). */
/* L'en-tête de Streamlit est rendu transparent et se superpose à notre barre du haut : ses boutons (Share, GitHub… sur
   Streamlit Cloud) s'affichent dans le coin droit de la barre blanche, dont la marge droite leur laisse la place. */
[data-testid="stHeader"] { background: transparent !important; pointer-events: none; }
[data-testid="stHeader"] * { pointer-events: auto; }
body:has([data-testid="stHeader"] [data-testid="stToolbar"]) div.st-key-topbar_droite { padding-right: 230px; }

/* Barre latérale */
[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] span { font-size: 0.93rem; }
/* Logo (st.logo) : Togo en miniature et nom du tableau de bord, en face du bouton qui replie la barre */
[data-testid="stSidebarHeader"] { height: auto !important; min-height: 6.6rem; align-items: center; padding-top: 1rem !important; padding-bottom: 0.4rem !important; }
[data-testid="stSidebarHeader"] img { height: auto !important; width: 100% !important; max-width: 100% !important; max-height: 7rem; object-fit: contain; object-position: left center; }
[data-testid="stSidebarHeader"] > div:first-child { flex: 1 1 auto !important; min-width: 0; max-width: none !important; width: auto !important; margin-right: 0.6rem; }
/* Sélecteur de langue : sous le logo, au-dessus du menu (il est rendu dans le contenu de la barre, puis remonté) */
[data-testid="stSidebarContent"] { position: relative; }
div.st-key-selecteur_langue { position: absolute; top: 7.9rem; left: 1.5rem; right: 1.5rem; z-index: 2; gap: 0.3rem; }
[data-testid="stSidebarNav"] { margin-top: 4.4rem; }
.langue-lib { margin-bottom: 8px; font-size: 0.68rem; font-weight: 600; letter-spacing: 0.08em; text-transform: uppercase; color: #cbd5e1; }
div.st-key-selecteur_langue [data-testid="stButtonGroup"] { background: rgba(255,255,255,0.06); border: 1px solid #24415c;
  border-radius: 999px; padding: 3px; width: fit-content; }
[data-testid="stSidebar"] div.st-key-selecteur_langue button[data-variant] { background: transparent !important; border: 0 !important; border-radius: 999px !important;
  min-height: 0 !important; padding: 4px 11px !important; color: #cbd5e1 !important; }
div.st-key-selecteur_langue button p { font-size: 0.78rem !important; font-weight: 600; color: inherit !important; }
[data-testid="stSidebar"] div.st-key-selecteur_langue button[data-variant][aria-pressed="true"], [data-testid="stSidebar"] div.st-key-selecteur_langue button[data-variant][aria-checked="true"],
[data-testid="stSidebar"] div.st-key-selecteur_langue button[data-variant][data-selected="true"] { background: #1769aa !important; color: #ffffff !important; }
/* Slogan et illustration de route, poussés en bas de la barre latérale quand la place le permet */
[data-testid="stSidebarContent"] { display: flex; flex-direction: column; }
[data-testid="stSidebarUserContent"] { flex: 1 0 auto; display: flex; flex-direction: column; }
[data-testid="stSidebarUserContent"] > div, [data-testid="stSidebarUserContent"] > div > [data-testid="stVerticalBlock"] { flex: 1 0 auto; display: flex; flex-direction: column; }
[data-testid="stSidebarUserContent"] [data-testid="stElementContainer"]:has(.slogan-barre) { margin-top: auto; }
.slogan-barre { padding: 1.6rem 0 0; }
.slogan-texte { font-style: italic; font-size: 1.02rem; line-height: 1.5; color: #e7eef8; margin: 0 0 0.9rem; }
.slogan-filet { width: 1.6rem; height: 2px; background: #2ec4b6; border-radius: 2px; margin-bottom: 1.4rem; }
.slogan-illustration { display: block; width: 100%; height: auto; opacity: 0.95; }
[data-testid="stSidebar"] [data-testid="stNavSectionHeader"] { text-transform: uppercase; letter-spacing: 0.08em; font-size: 0.72rem; color: #cbd5e1; }
[data-testid="stSidebarNavLink"] { border: 1.5px solid transparent; border-radius: 8px; }
/* Navigation active : bleu soutenu (le jaune du drapeau reste réservé aux mises en évidence) */
[data-testid="stSidebarNavLink"][aria-current="page"] { background: #1769aa !important; border-color: #1769aa !important; }
[data-testid="stSidebarNavLink"][aria-current="page"] span { color: #ffffff !important; }
[data-testid="stSidebarNavLink"]:hover { background: rgba(23,105,170,0.25) !important; }
[data-testid="stSidebar"] [data-testid="stSidebarNavLink"] span { color: #f8fafc; }
/* Filtres : fond blanc, bordure gris clair, état sélectionné bleu */
[data-testid="stSidebar"] button[data-variant="pills"] { background: #ffffff !important; border: 1px solid #e2e8f0 !important; color: #172b3a !important; }
[data-testid="stSidebar"] button[data-variant="pills"][aria-pressed="true"] { background: #1769aa !important; border-color: #1769aa !important; color: #ffffff !important; }
[data-testid="stSidebar"] button[data-variant="pills"] p { color: inherit !important; }
[data-testid="stSidebar"] [data-testid="stWidgetLabel"] p { text-transform: uppercase; letter-spacing: 0.07em; font-size: 0.74rem !important;
  font-weight: 700; color: #cbd5e1 !important; }
[data-testid="stSidebar"] [data-testid="stWidgetLabel"] { margin-top: 0.5rem; }
[data-testid="stSidebarCollapseButton"], [data-testid="stExpandSidebarButton"] { display: flex !important; visibility: visible !important; opacity: 1 !important; }
[data-testid="stSidebarCollapseButton"] button, [data-testid="stExpandSidebarButton"] { background: transparent !important; border: 1.5px solid #cbd5e1 !important; border-radius: 8px !important; }
[data-testid="stSidebarCollapseButton"] button:hover, [data-testid="stExpandSidebarButton"]:hover { background: rgba(203,213,225,0.15) !important; }

/* En-tête de page */
.ariane { font-size: 0.85rem; color: #64748b; margin-bottom: 0.4rem; }
.ariane b { color: #172b3a; }
.surtitre { font-size: 0.78rem; letter-spacing: 0.08em; text-transform: uppercase; color: #0b263d; font-weight: 600; }
.question { font-family: 'Fraunces', Georgia, serif; font-size: 2.6rem; font-weight: 600; line-height: 1.1; margin: 0.2rem 0 0.5rem; color: #172b3a; }
.reponse { font-size: 1.05rem; line-height: 1.5; color: #334155; max-width: 880px; margin-bottom: 0.6rem; }
.reponse.en-carte { max-width: none; background: #ffffff; border: 1px solid #e2e8f0; border-left: 4px solid #0b263d; border-radius: 14px;
  padding: 16px 22px; margin: 0.4rem 0 1rem; box-shadow: 0 1px 8px rgba(13,54,107,0.06); }
.filtres-actifs { font-size: 0.85rem; color: #334155; background: #ffffff; border: 1px solid #e2e8f0; border-radius: 10px; padding: 8px 12px; margin-bottom: 0.6rem; }

/* Chiffres clés */
.groupe { font-size: 0.82rem; font-weight: 600; color: #64748b; margin: 0.6rem 0 0.4rem; }
.kpi-grille { display: grid; grid-template-columns: repeat(auto-fit, minmax(230px, 1fr)); gap: 12px; margin-bottom: 6px; }
.kpi { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; box-shadow: 0 1px 2px rgba(11,38,61,0.04); padding: 16px 18px; display: flex; flex-direction: column; gap: 6px; box-sizing: border-box;
       position: relative; overflow: hidden; transition: transform 0.25s ease, box-shadow 0.25s ease, border-color 0.25s ease; }
.kpi::after { content: ""; position: absolute; top: 0; left: -80%; width: 50%; height: 100%; pointer-events: none;
              background: linear-gradient(115deg, transparent, rgba(252,229,136,0.45), transparent); transform: skewX(-20deg); }
.kpi:hover { transform: translateY(-2px); border-color: #1769aa; box-shadow: 0 8px 20px rgba(11,38,61,0.08); }
.kpi:hover::after { left: 130%; transition: left 0.8s ease; }
@media (prefers-reduced-motion: reduce) { .kpi, .kpi:hover { transform: none; transition: none; } .kpi::after { display: none; } }
/* Six chiffres clés sur une ligne (Vue nationale) : 3 puis 2 colonnes sur écran étroit */
.kpi-grille.une-ligne { grid-template-columns: repeat(6, minmax(0, 1fr)); gap: 10px; }
.kpi-grille.une-ligne .kpi { padding: 14px 14px; }
.kpi-grille.une-ligne .kpi-valeur { font-size: 1.75rem; }
.kpi-grille.une-ligne .kpi-phrase { font-size: 0.86rem; }
.kpi-grille.une-ligne .kpi-contexte { font-size: 0.78rem; margin-top: 8px; }
.kpi-grille.une-ligne .kpi-libelle { font-size: 0.72rem; letter-spacing: 0.01em; color: #172b3a; overflow-wrap: normal; }
.kpi-periode { font-size: 0.8rem; font-weight: 500; text-transform: none; letter-spacing: 0; color: #64748b; margin-top: 2px; }
.kpi-grille.une-ligne .kpi-tete { gap: 10px; min-height: 3.9rem; }
.kpi-grille.une-ligne .kpi-tete .kpi-libelle { align-self: flex-start; padding-top: 1px; }
/* Bloc central (chiffre, tendance, phrase), centré dans la carte ; liseré fin en bas, couleur du thème */
.kpi-grille.une-ligne .kpi-centre { flex: 1 0 auto; display: flex; flex-direction: column; align-items: center; justify-content: flex-start;
  text-align: center; gap: 6px; padding: 12px 0 8px; }   /* haut aligné : les chiffres restent sur une même ligne */
.kpi-grille.une-ligne .kpi { border-bottom-width: 3px; }
/* Tendance : badge arrondi coloré (rouge = aggravation, vert = amélioration démontrée, gris = variation neutre) */
.kpi-tendance { display: inline-flex; align-items: center; gap: 5px; padding: 3px 10px; border-radius: 999px; font-size: 0.78rem;
  font-weight: 700; white-space: nowrap; }
.kpi-tendance small { font-weight: 500; opacity: 0.85; }
.kpi-tendance.pire { background: #fbe3e5; color: #a00d1e; }
.kpi-tendance.mieux { background: #dff1e7; color: #005a35; }
.kpi-tendance.neutre { background: #eef2f6; color: #475569; }
@media (max-width: 1350px) { .kpi-grille.une-ligne { grid-template-columns: repeat(3, minmax(0, 1fr)); } }
@media (max-width: 760px) { .kpi-grille.une-ligne { grid-template-columns: repeat(2, minmax(0, 1fr)); } }
/* Pastille d'icône du thème, à gauche du libellé (même forme arrondie que les étiquettes A/B/C) */
.kpi-icone { flex: 0 0 auto; width: 34px; height: 34px; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; }
.kpi-icone svg { width: 19px; height: 19px; }
.kpi-tete .kpi-libelle { flex: 1 1 auto; min-width: 0; align-self: center; }
.kpi-tete { display: flex; justify-content: space-between; align-items: flex-start; gap: 8px; min-height: 2.5rem; }
.kpi-libelle { font-size: 0.76rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.02em; line-height: 1.35; color: #0b263d; }
.kpi-valeur { font-family: 'Fraunces', Georgia, serif; font-size: 2.2rem; font-weight: 600; line-height: 1.1; color: #0b263d; }
.kpi-unite { font-family: 'IBM Plex Sans', system-ui, sans-serif; font-size: 1.05rem; font-weight: 600; margin-left: 6px; }
.kpi-phrase { font-size: 0.95rem; font-weight: 600; line-height: 1.4; color: #172b3a; }
.kpi-contexte { font-size: 0.84rem; line-height: 1.45; color: #334155; }
.kpi-reserve { font-size: 0.78rem; line-height: 1.4; color: #64748b; border-top: 1px solid #eef2f6; padding-top: 7px; margin-top: auto; }
.etiquette { font-size: 0.74rem; font-weight: 600; padding: 3px 8px; border-radius: 999px; white-space: nowrap; }
.etiquette.alerte { background: #fdf0d2; color: #6b4700; }
.etiquette.ok { background: #e3eefb; color: #0b263d; }
.etiquette.critique { background: #fbe3e2; color: #8a1c1b; }
.etiquette.neutre { background: #eef2f6; color: #334155; }
.etiquette.national { background: #eef2f6; color: #64748b; font-weight: 500; }

/* Cartes de recommandation (reco-carte = inline HTML, hover sans balayage) */
.reco-carte { transition: transform 0.25s ease, box-shadow 0.25s ease; }
.reco-carte:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(11,38,61,0.08); }
@media (prefers-reduced-motion: reduce) { .reco-carte, .reco-carte:hover { transform: none; transition: none; } }
div[class*="st-key-carte_reco_"] { background: #ffffff; border: 1px solid #e2e8f0 !important; border-radius: 18px !important; padding: 18px 20px !important;
  box-shadow: 0 1px 6px rgba(13,54,107,0.06); transition: transform 0.25s ease, box-shadow 0.25s ease; }
div[class*="st-key-carte_reco_"]:hover { transform: translateY(-4px); box-shadow: 0 12px 28px rgba(13,54,107,0.14); }
@media (prefers-reduced-motion: reduce) { div[class*="st-key-carte_reco_"], div[class*="st-key-carte_reco_"]:hover { transform: none; transition: none; } }
/* Cartes des quatre thèmes : carte blanche arrondie, liseré bas de la couleur du titre, survol sans balayage */
[data-testid="stColumn"]:has(.reco-theme) { background: #ffffff; border: 1px solid #e2e8f0;
  border-bottom: 3px solid #0b263d; border-radius: 12px; padding: 16px 16px 12px; box-shadow: 0 1px 2px rgba(11,38,61,0.04);
  transition: transform 0.25s ease, box-shadow 0.25s ease; }
[data-testid="stColumn"]:has(.reco-theme):hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(11,38,61,0.08); }
[data-testid="stColumn"]:has(.reco-theme.mob) { border-bottom-color: #1c5cab; }
[data-testid="stColumn"]:has(.reco-theme.sec) { border-bottom-color: #b45309; }
[data-testid="stColumn"]:has(.reco-theme.res) { border-bottom-color: #b4451a; }
[data-testid="stColumn"]:has(.reco-theme.couv) { border-bottom-color: #11613f; }
@media (prefers-reduced-motion: reduce) { [data-testid="stColumn"]:has(.reco-theme):hover { transform: none; } }
/* Bouton « Voir le détail » toujours en bas de sa carte : cartes de même hauteur, dernier élément poussé en bas */
[data-testid="stHorizontalBlock"]:has(.reco-theme) { align-items: stretch; }
[data-testid="stColumn"]:has(.reco-theme) > [data-testid="stVerticalBlock"] { height: 100%; }
[data-testid="stColumn"]:has(.reco-theme) [data-testid="stElementContainer"]:has(button) { margin-top: auto; }
/* « Voir le détail » : survol bleu, comme la navigation de la barre latérale */
[class*="st-key-vn_t_"] button { transition: background 0.2s ease, color 0.2s ease, border-color 0.2s ease; }
[class*="st-key-vn_t_"] button:hover { background: #e8f0fb !important; border-color: #9fbde9 !important; color: #0b263d !important; }
[class*="st-key-vn_t_"] button:hover p { color: #0b263d !important; }
/* Boutons radio : contour visible même non sélectionnés */
[data-testid="stRadioOption"]:not([data-selected="true"]) > div > div > div:first-child { box-shadow: inset 0 0 0 2px #64748b; background: #ffffff; }
.reco-theme { display: flex; align-items: center; gap: 10px; margin-bottom: 8px; }
.reco-pastille { width: 34px; height: 34px; border-radius: 10px; display: inline-flex; align-items: center; justify-content: center; flex-shrink: 0; }
.reco-theme-lib { font-size: 0.72rem; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; }
.reco-titre { font-family: 'Fraunces', Georgia, serif; font-size: 1.12rem; font-weight: 600; color: #172b3a; line-height: 1.3; margin: 2px 0 6px; }
.reco-cible { font-size: 0.92rem; color: #172b3a; line-height: 1.45; margin-bottom: 4px; }
.reco-contexte { font-size: 0.84rem; color: #64748b; margin-bottom: 8px; }
.reco-horizon2031 { font-size: 0.84rem; color: #0b263d; background: #e8f0fb; border-radius: 8px; padding: 6px 10px; margin: 6px 0; line-height: 1.4; }
.etiquette.reco-priorite { background: #fdf0d2; color: #6b4700; }
.etiquette.reco-nature { background: #ece9fb; color: #4a3aa7; }
.etiquette.reco-horizon { background: #e2f4ec; color: #11613f; }

/* Blocs, constat, synthèse, limite */
.bloc-titre { font-family: 'Fraunces', Georgia, serif; font-size: 1.3rem; font-weight: 600; color: #172b3a; margin-bottom: 0.2rem; }
.bloc-sous-titre { font-size: 0.86rem; color: #64748b; line-height: 1.45; margin-bottom: 0.4rem; }
.constat { background: #ffffff; border: 1px solid #e2e8f0; border-left: 4px solid #fcd116; border-radius: 14px; padding: 16px 18px; margin-bottom: 14px; }
.constat-titre, .limite-titre, .synthese-titre { font-size: 0.78rem; font-weight: 600; text-transform: uppercase; letter-spacing: 0.06em; }
.constat-titre { color: #0b263d; }
.constat-texte { font-size: 0.95rem; line-height: 1.5; color: #172b3a; margin-top: 4px; }
.synthese { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 20px 24px; display: grid; grid-template-columns: 280px 1fr; gap: 26px; align-items: center; margin-top: 8px; }
.synthese-titre { color: #64748b; }
.synthese-chiffre { font-family: 'Fraunces', Georgia, serif; font-size: 2.6rem; font-weight: 600; color: #0b263d; line-height: 1.05; margin: 4px 0; }
.synthese-legende { font-size: 0.88rem; line-height: 1.45; }
.synthese ul { margin: 0; padding-left: 18px; display: flex; flex-direction: column; gap: 8px; font-size: 0.92rem; line-height: 1.5; }
.limite { background: #fdf3d7; border: 1px solid #ecd28f; border-radius: 14px; padding: 14px 18px; margin-top: 14px; }
.limite-titre { color: #6b4700; }
.limite-liste { margin: 8px 0 0; padding-left: 18px; display: flex; flex-direction: column; gap: 8px; font-size: 0.92rem;
  line-height: 1.5; color: #3a2a00; }
/* Rangées de cartes de même hauteur (points d'attention ; synthèse et limite côte à côte) */
[data-testid="stHorizontalBlock"]:has(.carte-egale) { align-items: stretch; }
[data-testid="stColumn"]:has(.carte-egale) > [data-testid="stVerticalBlock"] { height: 100%; }
[data-testid="stColumn"]:has(.carte-egale) [data-testid="stElementContainer"]:has(.carte-egale) { flex: 1 1 auto; }
[data-testid="stColumn"]:has(.carte-egale) [data-testid="stElementContainer"]:has(.carte-egale) .stMarkdown,
[data-testid="stColumn"]:has(.carte-egale) [data-testid="stElementContainer"]:has(.carte-egale) .stMarkdown > div,
[data-testid="stColumn"]:has(.carte-egale) [data-testid="stElementContainer"]:has(.carte-egale) [data-testid="stMarkdownContainer"],
[data-testid="stColumn"]:has(.carte-egale) .carte-egale { height: 100%; box-sizing: border-box; margin-top: 0; margin-bottom: 0; }
.lieu { color: #4a3aa7; font-weight: 600; }
/* Encarts « Ce qui n'a pas de territoire » : carte blanche à liseré gauche coloré par le verdict */
[class*="st-key-enc_"] { background: #ffffff; border: 1px solid #e2e8f0; border-left: 4px solid #e2e8f0; border-radius: 12px; overflow: hidden;
  padding: 12px 16px; margin-bottom: 10px; }
.encart-tete { font-size: 0.9rem; color: #172b3a; }
.encart-verdict { font-weight: 700; text-transform: lowercase; }
.encart-chiffre { font-family: 'Fraunces', Georgia, serif; font-size: 1.6rem; font-weight: 600; color: #0b263d; line-height: 1.1; margin-top: 2px; }
.encart-legende { font-size: 0.78rem; color: #64748b; line-height: 1.4; }
/* Tableau à badges de verdict (remplace le fond de cellule coloré) */
.tbl-verdict { overflow: auto; border: 1px solid #e2e8f0; border-radius: 12px; background: #ffffff; margin-bottom: 0.4rem; }
.tbl-verdict table { width: 100%; border-collapse: collapse; font-size: 0.86rem; }
.tbl-verdict thead th { position: sticky; top: 0; background: #f1f4f8; color: #0b263d; font-weight: 700; text-align: left;
  padding: 9px 12px; border-bottom: 1px solid #e2e8f0; white-space: nowrap; z-index: 1; }
.tbl-verdict td { padding: 9px 12px; border-bottom: 1px solid #eef2f6; color: #172b3a; vertical-align: top; line-height: 1.45; }
.tbl-verdict tbody tr:hover { background: #f7f9fc; }
.verdict-badge { display: inline-block; border-radius: 999px; padding: 2px 10px; font-size: 0.78rem; font-weight: 600; white-space: nowrap; }
.habitants { color: #ce1126; font-weight: 600; white-space: nowrap; }
.limite-texte { font-size: 0.9rem; line-height: 1.5; color: #3a2a00; margin-top: 4px; }
.limite.discret { background: transparent; border: 0; border-top: 1px solid #e2e8f0; border-radius: 0; padding: 12px 0 0; margin-top: 18px; }
.limite.discret .limite-titre { color: #64748b; }
.limite.discret .limite-texte { font-size: 0.86rem; color: #64748b; }

/* Listes (étapes, écarts, actions) */
.etapes { list-style: none; padding: 0; margin: 0; display: flex; flex-direction: column; }
.etape { display: grid; grid-template-columns: 54px 1fr; gap: 16px; padding: 14px 0; border-bottom: 1px solid #eef2f6; }
.etape:last-child { border-bottom: 0; }
.etape-num { width: 54px; height: 54px; border-radius: 14px; display: flex; align-items: center; justify-content: center;
  font-family: 'Fraunces', Georgia, serif; font-size: 1.4rem; font-weight: 600; }
.etape-titre { font-size: 1rem; font-weight: 700; color: #172b3a; }
.etape-desc { font-size: 0.88rem; color: #64748b; line-height: 1.5; margin-top: 2px; }
.etape-sortie { font-size: 0.82rem; color: #0b263d; background: #f4f7fc; border-left: 3px solid #86b6ef; border-radius: 6px; padding: 7px 10px; margin-top: 6px; }

/* Pied de page */
.pied { font-size: 0.8rem; color: #64748b; margin-top: 18px; }
.pied-identite { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 12px; padding: 16px 24px;
  margin-top: 20px; text-align: center; box-shadow: 0 1px 4px rgba(13,54,107,0.06); }
.pied-identite-titre { font-size: 0.92rem; font-weight: 800; color: #0b263d; line-height: 1.4; }
.pied-identite-sous-titre { font-size: 0.78rem; color: #64748b; margin-top: 4px; line-height: 1.5; }

/* Barre du haut (maquette §4) : armoiries + ministère · nom du projet + drapeau · carte logo Togo AI Lab */
.topbar-ligne { display: flex; align-items: center; gap: 10px; }
.armoiries { height: 38px; width: auto; flex-shrink: 0; }
.armoiries-repli { font-size: 1.4rem; flex-shrink: 0; }
.topbar-ministere { font-size: 0.76rem; color: #334155; line-height: 1.3; }
.topbar-centre { text-align: center; }
.topbar-titre { font-family: 'Fraunces', Georgia, serif; font-size: 1.2rem; font-weight: 600; color: #0b263d; }
.topbar-centre::after { content: ""; display: block; width: 56px; height: 3px; margin: 7px auto 0; border-radius: 2px;
  background: linear-gradient(90deg, #006b3f 0 34%, #fcd116 34% 67%, #ce1126 67% 100%); }
.topbar-sous-titre { font-size: 0.76rem; color: #64748b; font-style: italic; margin-top: 1px; }
.ai-lab-logo-carte { display: inline-flex; align-items: center; justify-content: center; background: #ffffff;
  border: 2px solid #ffce00; border-radius: 12px; padding: 7px 12px; box-shadow: 0 2px 6px rgba(0,0,0,0.08); height: 56px; }
.ai-lab-logo-carte img { height: 40px; width: auto; max-width: 140px; object-fit: contain; }
.ai-lab-logo-repli { font-size: 0.55rem; font-weight: 700; color: #dc2626; line-height: 1.2; text-align: center; }
[data-testid="stVerticalBlockBorderWrapper"]:has(div.st-key-topbar) { margin-bottom: 0.8rem; }
div.st-key-topbar { background: #ffffff; min-height: 92px; padding: 16px 22px; box-shadow: 0 1px 8px rgba(13,54,107,0.08);
  margin-bottom: 0.6rem; box-sizing: border-box; border: 1px solid #e2e8f0; border-radius: 18px; }
div.st-key-topbar [data-testid="stHorizontalBlock"] { align-items: center; }
div.st-key-topbar_droite { display: flex; align-items: center; justify-content: flex-end; }
div.st-key-topbar_droite [data-testid="stMarkdownContainer"] { display: flex; justify-content: flex-end; }

/* Graphiques et cartes sur fond blanc */
[data-testid="stPlotlyChart"] { background: #ffffff; border-radius: 10px; }

/* Sous-onglets en pastilles */
.stTabs [role="tablist"] { gap: 4px; background: #ffffff; padding: 6px; border-radius: 12px; border: 1px solid #e2e8f0;
  box-shadow: 0 1px 4px rgba(13,54,107,0.06); flex-wrap: wrap; }
.stTabs [data-testid="stTab"] { border-radius: 8px; padding: 7px 15px; height: auto; margin: 0; flex: 1 1 auto; justify-content: center; text-align: center; }
.stTabs [data-testid="stTab"] p { font-size: 0.9rem; font-weight: 600; color: #64748b; }
.stTabs [data-testid="stTab"]:hover { background: #e8f0fb; }
.stTabs [data-testid="stTab"]:hover p { color: #0b263d; }
.stTabs [data-testid="stTab"][aria-selected="true"] { background: #0b263d !important; }
.stTabs [data-testid="stTab"][aria-selected="true"] p { color: #ffffff !important; }
.stTabs .react-aria-SelectionIndicator { display: none; }
.onglets-aide { font-size: 0.84rem; font-weight: 600; color: #334155; margin: 0.8rem 0 0.3rem; }
.onglets-repere { font-size: 0.82rem; font-style: italic; color: #64748b; margin: 0.1rem 0 0.4rem; }
.note-graphique { font-size: 0.875rem; line-height: 1.5; color: #0b263d; margin: 0.2rem 0 0.6rem; }
.note-graphique.forte { font-weight: 700; }
/* Note en carte (repères sous un graphique) : fond bleu clair, filet bleu à gauche */
.note-carte { background: #eef4fd; border-left: 4px solid #1769aa; border-radius: 8px; padding: 12px 16px; margin: 0.4rem 0 0.8rem;
  font-size: 0.9rem; line-height: 1.7; color: #172b3a; }
.note-carte.blanche { background: #ffffff; border: 1px solid #e2e8f0; border-left: 4px solid #1769aa; }
.note-carte.blanche.risque { border-left-color: #ce1126; }
/* « À savoir » : pictogramme « i » cerclé avant le texte */
.note-carte.lisere-vert { border-left-color: #16834a; } .note-carte.lisere-vert .info-i { background: #16834a; }
.note-carte.lisere-rouge { border-left-color: #ce1126; } .note-carte.lisere-rouge .info-i { background: #ce1126; }
.note-carte.lisere-jaune { border-left-color: #e6b422; } .note-carte.lisere-jaune .info-i { background: #e6b422; color: #3a2e00; }
/* Titre du bloc de réglages propre à la page Carte, dans la barre latérale */
.reglages-carte-titre { font-size: 0.72rem; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase;
  color: #1769aa; margin: 0.6rem 0 0.2rem; border-top: 1px solid #e2e8f0; padding-top: 0.7rem; }
/* Repères chiffrés sous le bouton « Réinitialiser les filtres », en liste à puces discrète */
ul.sidebar-stats { margin: 0.7rem 0 0; padding-left: 16px; display: flex; flex-direction: column; gap: 5px;
  font-size: 0.74rem; line-height: 1.35; color: #64748b; }
ul.sidebar-stats li::marker { color: #94a3b8; }
/* Chiffres clés centrés (rangee_kpi(centre=True)) */
.kpi-grille.centre .kpi { border-bottom-width: 3px; }
.kpi-grille.centre .kpi-reserve { text-align: center; border-top: 0; margin-top: 8px; color: #64748b; }
.kpi-grille.centre .kpi-contexte { text-align: center; }
.kpi-grille.centre .kpi-centre { flex: 1 0 auto; display: flex; flex-direction: column; align-items: center; text-align: center;
  gap: 6px; padding: 8px 0 4px; }
/* Carte horizontale à liseré bleu : chiffre à gauche, texte à droite */
.carte-chiffre { display: grid; grid-template-columns: minmax(180px, 0.6fr) 2fr; gap: 28px; align-items: center; background: #ffffff;
  border: 1px solid #e2e8f0; border-left: 4px solid #1769aa; border-radius: 12px; padding: 18px 24px; margin: 0.4rem 0 0.8rem; }
.carte-chiffre-lib { font-size: 0.78rem; font-weight: 600; letter-spacing: 0.06em; text-transform: uppercase; color: #1769aa; }
.carte-chiffre .synthese-chiffre { margin: 2px 0 0; }
.carte-chiffre-texte { font-size: 0.98rem; line-height: 1.55; color: #172b3a; }
@media (max-width: 760px) { .carte-chiffre { grid-template-columns: 1fr; gap: 10px; } }
/* Cartes des zones (page Priorités, section « Diagnostic par zone ») */
.zone-grille { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; margin: 0.6rem 0 1rem; }
.zone-carte { background: #ffffff; border: 1px solid #e2e8f0; border-bottom: 3px solid; border-radius: 12px;
  padding: 14px 16px; transition: transform 0.25s ease, box-shadow 0.25s ease; }
.zone-carte:hover { transform: translateY(-2px); box-shadow: 0 8px 20px rgba(11,38,61,0.08); }
.zone-carte-nom { font-size: 0.88rem; font-weight: 700; margin-bottom: 6px; }
.zone-carte-texte { font-size: 0.84rem; line-height: 1.5; color: #334155; }
@media (max-width: 900px) { .zone-grille { grid-template-columns: repeat(2, 1fr); } }
@media (max-width: 600px) { .zone-grille { grid-template-columns: 1fr; } }
@media (prefers-reduced-motion: reduce) { .zone-carte, .zone-carte:hover { transform: none; transition: none; } }
.note-carte.a-savoir { display: flex; gap: 12px; align-items: flex-start; }
.info-i { flex: 0 0 22px; height: 22px; border-radius: 50%; background: #1769aa; color: #ffffff; font: 700 13px/22px Georgia, serif;
  text-align: center; font-style: italic; margin-top: 2px; }
/* Total des permis : carte bleu clair (même bleu que le survol de « Voir le détail ») */
.total-carte { background: #e8f0fb; border-radius: 14px; padding: 26px 14px; text-align: center; }
.total-chiffre { font-family: 'Fraunces', Georgia, serif; font-size: 2.8rem; font-weight: 600; color: #0b263d; line-height: 1; }
.total-legende { font-size: 0.92rem; color: #172b3a; margin-top: 8px; }
.total-note { font-size: 0.78rem; color: #64748b; margin-top: 8px; line-height: 1.4; }
/* Synthèse chiffrée (Vue nationale) : carte vert clair, bouton dedans, même hauteur que « À retenir » */
[data-testid="stHorizontalBlock"]:has(.retenir) { align-items: stretch; }
[data-testid="stColumn"]:has(.retenir) > [data-testid="stVerticalBlock"] { height: 100%; }
[data-testid="stColumn"]:has(.retenir) [data-testid="stElementContainer"]:has(.retenir) { flex: 1 1 auto; }
[data-testid="stColumn"]:has(.retenir) .stMarkdown, [data-testid="stColumn"]:has(.retenir) [data-testid="stMarkdownContainer"],
[data-testid="stColumn"]:has(.retenir) .retenir { height: 100%; box-sizing: border-box; }
[data-testid="stColumn"]:has(.st-key-vn_synthese) > [data-testid="stVerticalBlock"] { height: 100%; }
[data-testid="stColumn"]:has(.st-key-vn_synthese) [data-testid="stLayoutWrapper"]:has(.st-key-vn_synthese) { flex: 1 1 auto; display: flex; flex-direction: column; }
div.st-key-vn_synthese { flex: 1 1 auto; }
div.st-key-vn_synthese { background: #e6f4ec; border: 1px solid #b9dfc8; border-radius: 14px; padding: 20px 24px; height: 100%;
  justify-content: space-between; }
div.st-key-vn_synthese .synthese { background: transparent; border: 0; padding: 0; margin: 0;
  grid-template-columns: minmax(0, 0.85fr) minmax(0, 1.15fr); gap: 20px; }   /* chiffre à gauche, liste à droite */
div.st-key-vn_synthese .synthese ul { font-size: 0.88rem; gap: 6px; }
/* Contenu centré verticalement dans la carte ; liste alignée à gauche */
div.st-key-vn_synthese [data-testid="stElementContainer"]:has(.synthese) { flex: 1 1 auto; display: flex; align-items: center; }
div.st-key-vn_synthese [data-testid="stElementContainer"]:has(.synthese) > div { width: 100%; }
div.st-key-vn_synthese .synthese ul { text-align: left; }
div.st-key-vn_synthese [data-testid="stElementContainer"]:has(button) { align-self: flex-end; width: auto !important; }
div.st-key-vn_synthese button { min-height: 0; padding: 4px 12px; }
div.st-key-vn_synthese button p { font-size: 0.82rem; }
div.st-key-vn_synthese .synthese-titre { color: #11613f; }
div.st-key-vn_synthese .synthese-chiffre { color: #0b4d2e; }
div.st-key-vn_synthese .synthese ul { color: #173a2a; }
div.st-key-vn_synthese [data-testid="stElementContainer"]:has(button) { margin-top: auto; }
/* À retenir : carte blanche, messages numérotés en pastille */
.retenir { background: #ffffff; border: 1px solid #e2e8f0; border-radius: 14px; padding: 20px 24px; box-shadow: 0 1px 2px rgba(11,38,61,0.04); }
.retenir-titre { font-weight: 700; font-size: 1.05rem; color: #0b263d; margin-bottom: 10px; }
.retenir ol { list-style: none; margin: 0; padding: 0; }
.retenir li { display: flex; align-items: flex-start; gap: 12px; padding: 7px 0; font-size: 0.93rem; line-height: 1.5; color: #172b3a; }
.retenir-num { flex: 0 0 26px; height: 26px; border-radius: 50%; background: #e3ebfb; color: #0b263d; font-weight: 700; font-size: 0.82rem;
  display: inline-flex; align-items: center; justify-content: center; }
</style>
"""


def appliquer_theme():
    st.markdown(CSS, unsafe_allow_html=True)
